package com.example.katiechen.foodthree;

/**
 * Created by user on 12/2/2017.
 */

public class TestClass {
    String str = "Hello";
    public TestClass(){

    }
    public String getText(){
        return str;
    }
}
